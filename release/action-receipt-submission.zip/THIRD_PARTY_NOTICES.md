# Third-party components

This is a new application. No Review Reply Writer or other previous application code is incorporated.

- React, React DOM, Lucide and Zod are bundled in the static app; their licenses are embedded in the standalone HTML. Standard React, TypeScript, Vinext, Vite and Cloudflare libraries are listed in `package.json` and `pnpm-lock.yaml`, with their upstream licenses.
- The supplied Sites Vinext starter provided the initial hosting, build scripts and standard UI utilities. The active app now uses a plain Vite static build; retained Worker/Vinext scaffolding is not required by its runtime. Its license notices remain in `build/` and `vendor/`. These are standard development scaffolding, not newly authored application functionality.
- Devpost Learn Skill Pack was installed from https://github.com/challengepost/learn-ai-basics using its documented command. Its planning templates and instructions guided the documents in `devpost/`. The pack is MIT licensed; its notice is reproduced below. The installed pack itself is checkout-local and can be reinstalled using the documented command and `skills-lock.json`.
- Lucide provides the interface icons under its upstream license.
- Synthetic notice text and saved walkthrough results were newly created for this project. They are not real school announcements or model-performance evidence.

## Devpost Learn Skill Pack license

MIT License

Copyright (c) 2026 Devpost

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
